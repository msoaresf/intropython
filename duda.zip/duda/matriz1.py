import numpy as np


m = []

for i in range(3):
    for j in range(3):
        linhas=[]
        valor = int(input(f"Digite o valor para posiçao[{i}],[{j}]]: "))
        
        linhas.append(valor)
    print(linhas)    

